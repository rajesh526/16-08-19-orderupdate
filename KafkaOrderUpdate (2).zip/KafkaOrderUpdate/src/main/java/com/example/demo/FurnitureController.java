package com.example.demo;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FurnitureController {
	@Autowired
	ProductService service;
	@Autowired
	ProductStockRepository productrepository;
	@Autowired
	KafkaSender kafkaSender;

	
	
	@RequestMapping("/")
	public String index() {
		return "index";
		
	}
	@RequestMapping("/stock")
	public String stock() {
		return "Stock";
	}
	@RequestMapping(value="/upload",method=RequestMethod.POST)
	public String uploadStock(@RequestParam String id ,@RequestParam MultipartFile productimage,@RequestParam String productname ,@RequestParam int productcost,@RequestParam int productquantity) throws IOException {
		//byte[] data=productimage.getBytes();
		//Blob  image=(Blob) (new SqlLobValue(new ByteArrayInputStream(data), data.length ,new DefaultLobHandler()));
		
		FurnitureStock Fs=new FurnitureStock();
		Fs.setId(id);
		Fs.setProductname(productname);
		Fs.setProductcost(productcost);
		//Fs.setProductimage(image);
		Fs.setProductimage( new Binary(BsonBinarySubType.BINARY, productimage.getBytes()));
		Fs.setProductquantity(productquantity);
		
	
		
		
		productrepository.save(Fs);
		return "index";
		
	}
	
	//To get All results form database
		@RequestMapping(value="/get",method=RequestMethod.GET)
		public String ImageResults(Model model) {
			
			model.addAttribute("results", productrepository.findAll()); 
			
	               
			return "stockresult";
			
		}
		
		
		@RequestMapping(value="/get/{productname}" )
		@ResponseBody
		
		public void Result(HttpServletResponse response ,Model model,@PathVariable("productname") String productname)  throws IOException, SQLException {
			response.setContentType("image/jpeg,image/jpg,image/png,image/gif,image/jfif");
			
	      
	        //Blob blob =service.getPhotoByName( productname) ;
	        Binary binary =service.getPhotoByName( productname) ;
	        //byte[] bytes = blob.getBytes(1, (int)blob.length());
	        byte[] bytes = ((MultipartFile) binary).getBytes();
			InputStream inputStream = new ByteArrayInputStream(bytes); 
			IOUtils.copy(inputStream, response.getOutputStream());
	      
	              }
	
        @RequestMapping(value="/producer",method=RequestMethod.POST)
		public String producer(@RequestBody String item_name  ,String subtotal) {

			kafkaSender.send(item_name);
			return "index";

			
		}


}
