package com.example.demo;

import java.io.IOException;
import java.sql.SQLException;
import org.bson.types.Binary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
	@Autowired
	ProductStockRepository productrepository;
	@Autowired
	MongoTemplate mongotemplate;
	  @Autowired
	    private MongoOperations mongoOperations;
	
	 public FurnitureStock getPhoto(String id) { 
	        return productrepository.findById(id).get(); 
	    }
	 
	 
		
		

	 public Binary getPhotoByName(String productname) throws SQLException, IOException {
			
			//String query = "select image from upload where name= ?";
			Binary photo =mongoOperations.findOne(Query.query(Criteria.where("productname").is(productname)), Binary.class);
			return photo;
		}
}
